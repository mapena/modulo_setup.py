def sumar(n1,n2):
    return (n1+n2)

def sumar2(n1,n2):
    return 2*(n1+n2)