from setuptools import setup

setup(
      name="paquete_suma_resta",
      version="2.0.0",
      description="ejemplo de setup inicial",
      author="mp",
      author_email="mp@mp.com.ar",
      url="www.sarasa.com.ar",
      packages=["libreria","libreria.libresta"]


)